<?php
// stripped back template to make themeing Quicktabs easier.
?>
<div id="<?php print $block_html_id; ?>" class="<?php print $classes; ?>"<?php print $attributes; ?>>
  <div class="block-inner clearfix">
    <?php print $content ?>
  </div>
</div>
