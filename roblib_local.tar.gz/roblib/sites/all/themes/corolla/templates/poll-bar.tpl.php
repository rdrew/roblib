<div class="bar-wrapper">
  <div class="bar-text clearfix">
    <div class="text"><?php print $title; ?></div>
    <div class="percent"><?php print $percentage; ?>%</div>
  </div>
  <div class="bar">
    <div style="width: <?php print $percentage; ?>%;" class="foreground"></div>
  </div>
</div>
