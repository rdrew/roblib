<div class="topic-status-<?php print $icon_class ?>" title="<?php print $icon_title ?>">
  <?php if ($first_new): ?><a id="new"></a><?php endif; ?>
  <span class="element-invisible"><?php print $icon_title ?></span>
</div>
